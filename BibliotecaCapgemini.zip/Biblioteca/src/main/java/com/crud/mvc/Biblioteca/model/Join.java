package com.crud.mvc.Biblioteca.model;

public class Join {

	private String idLibro;
	private String nSocio;

	public String getIdLibro() {
		return idLibro;
	}

	public void setIdLibro(String idLibro) {
		this.idLibro = idLibro;
	}

	public String getNSocio() {
		return nSocio;
	}

	public void setNSocio(String nSocio) {
		this.nSocio = nSocio;
	}
}
